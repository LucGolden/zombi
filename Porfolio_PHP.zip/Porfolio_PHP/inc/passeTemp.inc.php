<hr>
<div class="container-fluid text-center">
<div class="row">
<div class="col-6 mt-5 offset-3 text-white btn apropos btn-block">
    <h2>Loisirs</h2>
  </div>
  </div>

<div class="row mt-4 offset-xl-3">
  
  
  <div class="col-xl-2 text-center mr-4 mb-5 text-white">

<i class="far fa-futbol iconL"></i><br><span>FOOTBALL</span> 

</div>
  <div class="col-xl-2 text-center  mb-5 text-white">
<i class="fas fa-gamepad iconL"></i><br> <span>JEUX VIDEO</span>


</div>
  <div class="col-xl-2 text-center mb-5 text-white">

  <i class="fas fa-film iconL"></i><br><span>SERIES & FILMS</span>

</div>
  <div class="col-xl-2 text-center text-white">

  <i class="fas fa-music iconL"></i><br><span>Musique</span>

</div>
</div>
</div>