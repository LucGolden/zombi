<body id="bodyCompetence"> 
<nav class="navbar mt-3 effet">
  <a class="btn navbar-brand border-danger rounded-circle" href="index.php"><i class="fas fa-home home"></i></a>
  <a class="btn border-warning" href="?lien=formations">Formations</a>
  <a class="btn border-danger bg-danger" href="?lien=competences">Compétences</a>
  <a class="btn border-info" href="?lien=realisations">Réalisations</a>
  <a class="btn border-primary" href="?lien=luc">A Propos</a>
  <a class="btn border-success " href="?lien=contact">Contacts</a>
</nav>

<div class="container text-danger mt-5 stylef effetA">


  <div class="row">
  <div class="col-12 mt-4 text-center">
    <h1 class="text-center">COMPETENCES</h1>
  </div>
  </div>
    <div class="row mt-3">
      <div class="col-xl-4 col-md-4 col-4 mt-xl-5 mt-3 text-center">
      
         <i class="fab fa-html5 icon"></i><br><span>HTML 5</span> 
          
      </div>
      <div class="col-xl-4 col-md-4 col-4 text-center">
          

         <i class="fab fa-css3 icon mt-xl-5 mt-3"></i><br><span>CSS 3</span> 
      </div>
      <div class="col-xl-4 col-md-4 col-4 text-center">
          

        <i class="fas fa-bold icon mt-xl-5 mt-3"></i><br><span>BOOTSTRAP</span> 
      </div>
      <div class="col-xl-4 col-md-4 col-4 text-center">
  

        <i class="fab fa-php icon mt-xl-5 mt-3"></i><br><span>PHP</span> 
      </div>
                  <div class="col-xl-4 col-md-4 col-4 text-center">

                     <i class="fab fa-js icon mt-xl-5 mt-3"></i><br><span>JAVASCRIPT</span> 
                  </div>
      
                  <div class="col-xl-4 col-md-4 col-4 text-center">

                    <i class="fab fa-wordpress icon mt-3 mt-xl-5"></i><br><span>Wordpress</span> 
                  </div>
      
    </div>

<?php  ?>

</div>
  
</body>