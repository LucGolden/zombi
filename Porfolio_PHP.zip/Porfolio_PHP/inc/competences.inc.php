<body id="bodyCompetence"> 
<nav class="navbar mt-3 effet">
  <a class="btn navbar-brand ml-5  border-danger rounded-circle" href="index.php"><i class="fas fa-home home"></i></a>
  <a class="btn border-warning mr-5" href="?lien=formations">Formations</a>
  <a class="btn border-danger bg-danger mr-5" href="?lien=competences">Compétences</a>
  <a class="btn border-info mr-5" href="?lien=realisations">Réalisations</a>
  <a class="btn border-primary mr-5" href="?lien=luc">A Propos</a>
  <a class="btn border-success  mr-5" href="?lien=contact">Contacts</a>
</nav>

<div class="container text-danger mt-5 stylef effetA">


  <div class="row">
  <div class="col-12 m-4 text-center">
    <h1 class="text-center">COMPETENCES</h1>
  </div></div>
    <div class="row mt-5">
      <div class="col-4 text-center">
          <img src="img/logo2.png" alt="HTML5" id="img"><br><span></span>
         <!-- <img src="img/visuel-sabri.jpg" alt="HTML">-->
      </div>
      <div class="col-4 text-center mb-">
          <img src="img/CSS3_logo_and_wordmark.svg.png" alt="HTML5" id="img"><br><span></span>

         <!--<i class="fab fa-css3 icon"></i><br><span>CSS 3</span>--> 
      </div>
      <div class="col-4 text-center">
          <img src="img/index.png" alt="css" id="img"><br><span></span>

        <!--<i class="fab fa-php icon"></i><br><span>PHP</span> -->
      </div>
      <div class="col-4 text-center">
          <img src="img/indexb.png" alt="bootstrap" id="img"><br><span></span>

        <!--<i class="fas fa-bold icon mt-5"></i></i><br><span>BOOTSTRAP</span> -->
      </div>
                  <div class="col-4 text-center">
          <img src="img/indx.png" alt="js" id="img"><br><span></span>

                    <!-- <i class="fab fa-js icon mt-5"></i><br><span>JAVASCRIPT</span> -->
                  </div>
      <div class="col-4 text-center">
         <i class="fab fa- icon"></i><br><span></span> 
      </div>

      <div class="col-4">

      </div>

      <div class="col-4">

      </div>

      <div class="col-4">

      </div>
    </div>

<?php  ?>

</div>
  
</body>