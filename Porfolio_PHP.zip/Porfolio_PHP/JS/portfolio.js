$(document).ready(function(){

    $('#jqueryEffet').hide();
    $('#jqueryEffet').fadeIn(3000);

    $('.effetA').hide();
    $('.effetA').show('slow');
    

    $('.bgcLien').hide();
    $('.bgcLien').show(2500);
    
    $('.effet').hide();
    $('.effet').fadeIn(3000);
 
    

    
    // $('.luc').show(7000);

});

