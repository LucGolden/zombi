<?php
// Connexion a la BDD
$pdo = new PDO('mysql:host=localhost;dbname=eval_cars', 'root', '');