// alert('Bonjour');
// prompt('nom');
// prompt('Prenom');


var nom = window.prompt('nom ');
 var prenom = prompt(' prenom');
//  console.log(nom)
//  console.log(prenom)

 var bonjour = alert('Bonjour' + " " +  nom + " " + prenom);
//  console.log(bonjour);
