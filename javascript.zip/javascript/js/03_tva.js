var ht = prompt('hors taxe');


var tva = 1.20;

var ttc = ht * tva;
console;log('prix ttc: ' + ttc);
alert(ht * tva);
document.write('<h3> Prix ttc : ' + ttc + '<h3>')
console.log(ht);

console.log(tva);


// var bonjour =ht * tva;

// console.log(bonjour);